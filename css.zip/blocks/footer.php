﻿<footer class="footer">
	<div class="footer-block">
		<div class="container">
		</div>
	</div>
	<div class="bottom">
		<div class="container">
			<div class="recv">
				<div class="row">
					<div class="col-sm-7">
						<div class="h3">ИП "Три пирога"</div>
					</div>
					<div class="col-sm-5">
						<div class="soc_links">
							<a href="https://www.instagram.com/3_piroga31/" target="_blank"
								onclick="ym(53557858,'reachGoal','click_inst'); return true;"><i
									class="fa fa-instagram"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-7">
					</div>
					<div class="col-sm-5">
						Телефон: 8 (920) 559-35-03<br />
						Адрес: 308017, Советская улица, дом 14, 41-й массив, посёлок Новосадовый, Белгородский
						район, Белгородская область, Россия.<br />
					</div>
				</div>
			</div>
			<p class="pull-left copyright">&copy; Три пирога 2023 - Семейная пекарня.</p>
		</div>
	</div>
</footer>