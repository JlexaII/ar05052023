﻿<div class="sc_wrap">
		<div class="sc_item">
			<a target="_blank" onclick="ym(53557858,'reachGoal','chat_whatsapp'); return true;"
				href="https://wa.me/79300881961"><img src="images/sc/wp.png" alt="whatsapp" /></a>
		</div>
		<div class="sc_item">

		</div>
	</div>

	<!--[if lt IE 9]>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<![endif]-->
	<!--[if (gte IE 9) | !IE]><!-->
	<!-- <script src="assets/d60908cc/jquery.min.js"></script>  Отключил его он мешал работать корзине нормально -->
	<!--<![endif]-->
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="assets/8cb4aa4e/yii.js"></script>
	<script type="text/javascript" src="/plugins/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript"
		src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
	<script src="../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
	<script src="js/app.js"></script>
	<script>jQuery(document).ready(function () {
			document.rub = 'руб.';
			$('#ny_info').on('click', function (e) {
				e.preventDefault();
				$('#ny_info_modal').remove();
				let modalContent = '<div id="ny_info_modal" class="modal modal-rsv fade">' +
					'<div class="modal-dialog">' +
					'<div class="modal-content">' +
					'<div class="modal-header text-center">' +
					'<button type="button" class="close" data-dismiss="modal" aria-label="Закрыть"><span aria-hidden="true">&times;</span></button>' +
					'<h4 class="modal-title">Внимание! Изменения в меню на 22 февраля!</h4>' +
					'</div>' +
					'<div class="modal-body" style="padding:0 30px 30px 30px;font-size:18px;">' +
					'<h3>Уважаемые клиенты!</h3><p>Обращаем Ваше внимание на то, что 22 февраля в связи с большой загрузкой пекарни для заказа НЕ ДОСТУПНЫ некоторые позиции нашей выпечки!</p><p>Все позиции из категорий:<br/>Сытные и сладкие пироги 700 гр.;<br/>Пироги с надписью;<br/>Ржаные пироги 500 гр.;<br/>Караваи;<br/>Кулебяки;<br/>Блинная горка.</p><p>Отдельные позиции:<br/>Ржаные пирожки с яблоками 600гр (10шт)<br/>Ржаные пирожки с сыром Креметте 650гр (10шт)<br/>Ржаные пирожки картофель с грибами 10шт (650г)<br/>Ржаные пирожки с капустой 650 гр (10шт)<br/>Булочки с маком 6шт (540г)<br/>Булочки с корицей 6шт (540г)<br/>Булочки с творогом и вишней 6шт (540г)<br/>Плюшки московские 6шт (480г)<br/>Улитки с яблоком и корицей 6шт (540г)</p><p>Наши менеджеры сделают все возможное, чтобы подобрать для Вас подходящую замену и сделать Ваше мероприятие особенным!</p>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'</div>';
				$('body').append(modalContent);
				$('#ny_info_modal').modal({}).modal('show');
			});
		});</script> <noscript>
		<div><img src="https://mc.yandex.ru/watch/53557858" style="position:absolute; left:-9999px;" alt="" /></div>
	</noscript>

	<script>
		setTimeout(function () {
			ym(53557858, 'getClientID', function (clientID) {
				setCookie('clientID', clientID, 30);
			});
		}, 1000);
	</script>